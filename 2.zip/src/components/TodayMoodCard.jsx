// src/components/TodayMoodCard.jsx
import React from "react";

const MOOD_MAP = {
  Happy: "😄",
  Calm: "😌",
  Neutral: "😐",
  Sad: "😔",
  Angry: "😠",
  Stressed: "😩",
  Excited: "😍",
};

export default function TodayMoodCard({ mood, dateText }) {
  // mood can be { emoji, label } or a string label
  let emoji = "🙂";
  let label = "Neutral";

  if (!mood) {
    label = "Neutral";
    emoji = MOOD_MAP[label];
  } else if (typeof mood === "string") {
    label = mood;
    emoji = MOOD_MAP[mood] || "🙂";
  } else if (typeof mood === "object") {
    label = mood.label || mood.mood || "Neutral";
    emoji = mood.emoji || MOOD_MAP[label] || "🙂";
  }

  return (
    <div className="today-card">
      <h3 className="today-title">Today's Mood Check</h3>
      <div className="today-content">
        <div className="today-emoji" aria-hidden>{emoji}</div>
        <div className="today-mood">{label}</div>
        <div className="today-date">{dateText}</div>
      </div>
    </div>
  );
}
