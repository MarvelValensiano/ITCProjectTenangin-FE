// src/components/LoginForm.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import SocialButton from "./SocialButton";
import { login as authLogin, setAccessToken, setUser } from "../services/auth";

export default function LoginForm() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Email dan password wajib diisi.");
      return;
    }
    setLoading(true);
    try {
      // call auth service login
      const data = await authLogin({ email, password });
      // backend expected to return data.accessToken and data.user
      const token = data?.accessToken;
      const user = data?.user || data?.userData || null;

      if (token) {
        // - if not remember => move token & user to sessionStorage
        if (!remember) {
          // ensure token in sessionStorage, remove from localStorage
          sessionStorage.setItem("accessToken", token);
          localStorage.removeItem("accessToken");
          if (user) {
            sessionStorage.setItem("user", JSON.stringify(user));
            localStorage.removeItem("user");
          }
        } else {
          // ensure stored in localStorage (authLogin already did this via auth.js typically)
          localStorage.setItem("accessToken", token);
          if (user) localStorage.setItem("user", JSON.stringify(user));
        }
      }

      // redirect to landing/dashboard
      navigate("/");
    } catch (err) {
      console.error("Login error:", err);
      // prefer server message if available
      const serverMsg = err?.data?.message || err?.message;
      setError(serverMsg || "Terjadi kesalahan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <form className="login-form" onSubmit={handleSubmit}>
        <div className="form-inner">

          <label className="field-label">
            Email Address
            <input
              type="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-label="Email"
              autoComplete="email"
            />
          </label>

          <label className="field-label">
            Password
            <input
              type="password"
              placeholder="Input your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-label="Password"
              autoComplete="current-password"
            />
            <small className="hint">It must be a combination of minimum 8 letters, numbers, and symbols.</small>
          </label>

          <div className="login-row">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              <span className="checkbox-text">Remember me</span>
            </label>

            <a className="forgot-link" href="/forgot">Forgot Password?</a>
          </div>

          {error && <div className="form-error">{error}</div>}

          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? "Loading..." : "Log In"}
          </button>
        </div>
      </form>

      <div className="social-login">
        <SocialButton provider="google" onClick={() => alert("Google login (implement)")}>
          Log in with Google
        </SocialButton>
        <SocialButton provider="apple" onClick={() => alert("Apple login (implement)")}>
          Log in with Apple
        </SocialButton>
      </div>

      <hr className="auth-sep" />
    </>
  );
}
