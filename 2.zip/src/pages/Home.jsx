// src/pages/Home.jsx
import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import HomeHeader from "../components/HomeHeader";
import MoodHistoryChart from "../components/MoodHistoryChart";
import TodayMoodCard from "../components/TodayMoodCard";
import { getStoredUser, getAccessToken } from "../services/auth";
import { SiteInfoA } from "../components/SiteInfo";
import "../styles/home.css";

/**
 * Fetches dashboard data from backend:
 * GET /api/data/data_dashboard
 * Header: Authorization: Bearer <accessToken>
 *
 * Expected response shape (example provided by backend):
 * {
 *   id, foto_profile_url, username, email, ..., moods: [], latest_mood: null
 * }
 *
 * Notes:
 * - moods is expected to be an array of mood records (we handle common shapes like { created_at, date, mood, label }).
 * - latest_mood may be null or contain the last mood record (we handle both).
 */

const MOOD_MAP = {
  Happy: "😄",
  Calm: "😌",
  Neutral: "😐",
  Sad: "😔",
  Angry: "😠",
  Stressed: "😩",
  Excited: "😍",
};

export default function Home() {
  const [user, setUser] = useState(null);
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [moods, setMoods] = useState([]); // array of { date: 'YYYY-MM-DD', mood: 'Happy' }
  const [today, setToday] = useState({ mood: { label: "Neutral", emoji: MOOD_MAP["Neutral"] }, dateText: "" });

  useEffect(() => {
    const stored = getStoredUser();
    if (stored) setUser(stored);

    const loadDashboard = async () => {
      try {
        const token = getAccessToken(); // reads localStorage 'accessToken'
        if (!token) {
          // no token: fallback to demo
          setFallback();
          return;
        }

        const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/data/data_dashboard`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        // parse JSON safely
        const data = await (async () => {
          try { return await res.json(); } catch { return null; }
        })();

        if (res.ok && data) {
          // set user/profile
          if (data.username || data.email || data.foto_profile_url) {
            setUser((prev) => ({ ...prev, username: data.username || prev?.username, email: data.email || prev?.email }));
            if (data.foto_profile_url) setAvatarUrl(data.foto_profile_url);
          }

          // process moods (backend promises `moods` array)
          if (Array.isArray(data.moods) && data.moods.length > 0) {
            // Normalize rhythm: expect each item to have either date or created_at and mood/label
            const normalized = data.moods.map((it) => {
              const raw = it.date || it.created_at || it.timestamp || it.day || null;
              const day = raw ? (raw.indexOf("T") > -1 ? raw.split("T")[0] : raw) : null;
              const label = it.mood || it.label || it.value_label || it.name || it.level || null;
              return { date: day, mood: label || "Neutral", rawItem: it };
            }).filter(Boolean);

            // If multiple entries per day, keep the last one (by created_at if available)
            const grouped = {};
            for (const rec of normalized) {
              if (!rec.date) continue;
              grouped[rec.date] = rec; // overwrite keeps last encountered
            }
            const mapped = Object.keys(grouped)
              .sort((a, b) => new Date(a) - new Date(b))
              .map((d) => ({ date: d, mood: grouped[d].mood }));

            setMoods(mapped);
          } else {
            // maybe backend provides latest_mood only
            if (data.latest_mood) {
              const raw = data.latest_mood.created_at || data.latest_mood.date || null;
              const d = raw ? (raw.indexOf("T") > -1 ? raw.split("T")[0] : raw) : getISODate(new Date());
              setMoods([{ date: d, mood: data.latest_mood.mood || data.latest_mood.label || "Neutral" }]);
            } else {
              // no moods array: fallback
              setFallback();
            }
          }

          // latest mood: prefer latest_mood if provided
          if (data.latest_mood) {
            const label = normalizeMoodLabel(data.latest_mood.mood || data.latest_mood.label || data.latest_mood.value || "Neutral");
            const created = data.latest_mood.created_at || data.latest_mood.date || null;
            setToday({
              mood: { label, emoji: MOOD_MAP[label] || "🙂" },
              dateText: created ? `Checked on ${formatDateHuman(created)}` : "",
            });
          } else {
            // if moods array exists, take last item
            const last = Array.isArray(data.moods) && data.moods.length ? data.moods[data.moods.length - 1] : null;
            if (last) {
              const label = normalizeMoodLabel(last.mood || last.label || last.value_label || "Neutral");
              const raw = last.created_at || last.date || null;
              setToday({
                mood: { label, emoji: MOOD_MAP[label] || "🙂" },
                dateText: raw ? `Checked on ${formatDateHuman(raw)}` : "",
              });
            }
          }

          return;
        } // end if res.ok
      } catch (err) {
        console.warn("Dashboard fetch failed:", err);
      }

      // fallback if anything fails
      setFallback();
    };

    loadDashboard();
  }, []);

  const setFallback = () => {
    // mock last 5 days
    const todayISO = getISODate(new Date());
    const mock = [
      { date: addDaysISO(todayISO, -4), mood: "Calm" },
      { date: addDaysISO(todayISO, -3), mood: "Neutral" },
      { date: addDaysISO(todayISO, -2), mood: "Happy" },
      { date: addDaysISO(todayISO, -1), mood: "Happy" },
      { date: todayISO, mood: "Happy" },
    ];
    setMoods(mock);
    setToday({ mood: { label: "Happy", emoji: MOOD_MAP["Happy"] }, dateText: "Checked on Oct 13, 2025 - 10:30 AM" });
  };

  const handleCheckMood = () => window.location.href = "/CheckMood";

  return (
    <div className="home-page">
      <Navbar avatarUrl={avatarUrl} />
      <main className="home-container">
        <HomeHeader userName={user?.nama || user?.username || user?.name || "User"} onCheckMood={handleCheckMood} />

        <div className="home-grid">
          <MoodHistoryChart data={moods} />
          <TodayMoodCard mood={today.mood} dateText={today.dateText} />
        </div>
      </main>

      <SiteInfoA />
      <Footer />
    </div>
  );
}

/* ---------- Helpers ---------- */

function normalizeMoodLabel(raw) {
  if (!raw) return "Neutral";
  const r = String(raw).trim();
  const key = r.charAt(0).toUpperCase() + r.slice(1).toLowerCase();
  if (key === "Joyful") return "Happy";
  if (key === "Relaxed") return "Calm";
  return key;
}

function getISODate(d = new Date()) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).toISOString().split("T")[0];
}

function addDaysISO(dateISO, delta = 0) {
  const d = new Date(dateISO);
  d.setDate(d.getDate() + delta);
  return getISODate(d);
}

function formatDateHuman(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return iso;
  }
}
