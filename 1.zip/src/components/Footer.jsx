import '../styles/Footer.css'

function footer() {
  return (
    <div>
      <footer>
        <p>© 2025 TENANGIN Team. Supporting SDG 3: Good Health and Well-being.</p>
      </footer>
    </div>
  )
}

export default footer
